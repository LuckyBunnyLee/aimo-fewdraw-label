"""Fixed constant-robust Small-track baseline; no import-time I/O."""
def are_robust(model_id: str, reasoning_effort: str, problems: list[str]) -> list[bool]:
    return [True for _ in problems]
